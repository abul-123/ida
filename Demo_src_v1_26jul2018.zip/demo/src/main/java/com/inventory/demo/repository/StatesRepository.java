package com.inventory.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.inventory.demo.model.States;

@Repository
public interface StatesRepository extends CrudRepository<States, Integer> {

}
