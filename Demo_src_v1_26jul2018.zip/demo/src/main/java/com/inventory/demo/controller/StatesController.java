package com.inventory.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inventory.demo.model.States;
import com.inventory.demo.repository.StatesRepository;

@RestController
public class StatesController {
	
	@Autowired
	private StatesRepository statesRepository;
	
	@RequestMapping(value="/states/",method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<States> getAllStates(){
		
		List<States> statesList =  new ArrayList<States>();
		statesRepository.findAll().forEach(statesList::add);
		return statesList;
	}

}
