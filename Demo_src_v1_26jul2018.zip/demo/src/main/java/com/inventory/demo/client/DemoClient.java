package com.inventory.demo.client;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.inventory.demo.model.Cities;
import com.inventory.demo.model.Countries;
import com.inventory.demo.model.States;

public class DemoClient {

	public static final String REST_SERVICE_URI = "http://localhost:9000";
	

	private static void getCountries() {
		System.out.println("Testing listAllUsers API-----------");

		try {
		RestTemplate restTemplate = new RestTemplate();

		ResponseEntity<Countries[]> response = restTemplate.getForEntity(REST_SERVICE_URI+"/countries/", Countries[].class);
		List<Countries> count = Arrays.asList(response.getBody());
		
		for(Countries country:count) {
		
			System.out.println("country="+country.getName());
			/*System.out.println("state size="+country.getStatesList().size());
			for(States states:country.getStatesList()) {
				System.out.println("state="+states.getName());	
			}*/
		}
		
		}catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println();
		}
	}
	
	private static void getStates() {
		System.out.println("Testing listAllUsers API-----------");

		try {
		RestTemplate restTemplate = new RestTemplate();

		ResponseEntity<States[]> response = restTemplate.getForEntity(REST_SERVICE_URI+"/states/", States[].class);
		List<States> count = Arrays.asList(response.getBody());
		
		for(States country:count) {
		
			System.out.println("state="+country.getName());
			/*System.out.println("state size="+country.getStatesList().size());
			for(States states:country.getStatesList()) {
				System.out.println("state="+states.getName());	
			}*/
			System.out.println("country:"+country.getCountries().getName());
		}
		
		}catch(Exception e) {
			System.out.println(e.getMessage());
			System.out.println();
		}
	}
	
	public static void testOne() {
		
		RestTemplate restTemplate = new RestTemplate();
		/*List<States> states= restTemplate.getForObject(REST_SERVICE_URI,Countries.class).getStates();
		System.out.println(states.size());*/
	}

	public static void main(String[] args) {
	getCountries();
	//	testOne();
	getStates();
	}

}
