package com.inventory.demo.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.inventory.demo.model.Cities;

@Repository
public interface CitiesRepository extends CrudRepository<Cities, Integer> {

}
