package com.inventory.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.inventory.demo.model.Countries;
import com.inventory.demo.repository.CountriesRepository;

@RestController
public class CountriesController {

	@Autowired
	private CountriesRepository countriesRepository;

	@RequestMapping(value="/countries/",method=RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Countries>>  getAllCountries() {
		
		/*String plainCreds = "willie:p@ssword";
		byte[] plainCredsBytes = plainCreds.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		String base64Creds = new String(base64CredsBytes);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic " + base64Creds);*/
		
		List<Countries> countries = new ArrayList<>();
		
//		countries.add(new Countries(1, "India", "IND", 91));
		//countries.add(new Countries(2, "Australia", "AUS", 95));
		countriesRepository.findAll().forEach(countries::add);
//		System.out.println("countries List:"+countries.get(0).getStates().get(0).getId());
		return new ResponseEntity<List<Countries>>(countries, HttpStatus.OK);
	}

}
