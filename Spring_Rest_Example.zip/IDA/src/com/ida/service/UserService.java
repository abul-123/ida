package com.ida.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ida.User;

@Service("userService")
@Transactional
public class UserService {

	public UserService() {
		// TODO Auto-generated constructor stub
	}

	private static final AtomicLong counter = new AtomicLong();

	private static List<User> users;

	static {
		users = populateDummyUsers();
	}

	public List<User> findAllUsers() {

		return users;
	}

	private static List<User> populateDummyUsers() {
		List<User> users = new ArrayList<User>();
		users.add(new User(counter.incrementAndGet() + "", "Sam"));
		users.add(new User(counter.incrementAndGet() + "", "Tom"));
		users.add(new User(counter.incrementAndGet() + "", "Jerome"));
		users.add(new User(counter.incrementAndGet() + "", "Silvia"));
		return users;
	}
}
