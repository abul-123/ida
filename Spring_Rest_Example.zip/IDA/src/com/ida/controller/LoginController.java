package com.ida.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ida.User;

@Controller
public class LoginController {

	@RequestMapping(value = "/index.html", method = RequestMethod.GET)
	public String user(@Validated User user, Model model) {

		System.out.println("User Login Requested");
		System.out.println("User Name:" + user.getUserName());

		model.addAttribute("userName", user.getUserName());
		return "Login";

	}
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginValidate(@Validated User user, Model model) {

		System.out.println("User Login Requested");
		System.out.println("User Name:" + user.getUserName());

		model.addAttribute("userName", user.getUserName());
		return "Login";

	}

}
